
class Treasure:
    type_name  = [weapon, armors, food, gold]
    
    
    def __init__(self, name,value,nutrition_value,defense_lvl,dmg_lvl,position,player_monster_possession, player_monster_worn,player_monster_wielded,description):
        if name not in self.type_name:
            return ValueError("%s is not a valid treasure/item" %name)
        self.name = name
        self.value = value
        self.nutrition_value = nutrition_value
        self.defense_lvl = defense_lvl
        self.dmg_lvl = dmg_lvl
        self.position = position
        self.player_monster_possession  = player_monster_possession
        self.player_monster_worn = player_monster_worn
        self.player_monster_wielded = player_monster_wielded
        self.description = description

    def Weapon(self, name,value,dmg_lvl,position,player_monster_possession, player_monster_wielded,description):
        self.name = weapon
        self.value = 10
        self.dmg_lvl = 5
        self.position = position
        self.player_monster_possession  = player_possession
        self.player_monster_worn = player_monster_worn
        self.player_monster_wielded = player_monster_wielded
        self.description = "it's pointy"


    def Armors(self,name,value,defense_lvl,position,player_monster_possession, player_monster_worn,description):
        self.name = armors
        self.value = 20        
        self.defense_lvl = 5        
        self.position = position
        self.player_monster_possession  = player_possession
        self.player_monster_worn = player_monster_worn        
        self.description = "extra padding"
             
    def Food(self, name,nutrition_value,position,player_monster_possession,description):
        self.name = food
        self.nutrition_value = 2
        self.position = position
        self.player_monster_possession  = player_possession
        self.description = "it's edible"


    def Gold(self, name,value,position,player_monster_possession,description):
        self.name = gold
        self.value = 5
        self.position = position
        self.player_monster_possession  = player_monster_possession
        self.description = "it's shiny"

    
