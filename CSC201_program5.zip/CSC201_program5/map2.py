

from random import randint
dimensions = []
width = randint(10,40)
height = randint(10,25)
totally_random = randint(1,height-1)
totally_random2 = randint(1,height-1)
totally_random3 = randint(1,height-1)
totally_random4 = randint(1,height-1)
totally_random5 = randint(1,height-1)
totally_random != totally_random2 != totally_random3 != totally_random4 != totally_random5
space = randint(1,width-3)

player_move = randint(1,width-3)

dimensions.append(width)
dimensions.append(height)
dimensions.append(totally_random)
dimensions.append(totally_random2)
dimensions.append(totally_random3)
dimensions.append(totally_random4)
dimensions.append(totally_random5)
dimensions.append(space)
dimensions.append(player_move)

def Move(move):
    constant = dimensions[4]
    if move == "up":
        dimensions[4] -= 1
    elif move == "down":
        dimensions[4] += 1
    elif move == "left":
        dimensions[8] -= 1
    elif move == "right":
        dimensions[8] += 1
    else:
        print("invalid")

    for i in range(0,dimensions[1],1):
        if i == 0 or i == dimensions[1]-1:
            print("#"*dimensions[0])
        else:
            if i == dimensions[2]:
                print("#"+("."*(dimensions[7]))+"u"+("."*(dimensions[0]-(dimensions[7]+3))+"#"))
            else:
                if i == dimensions[3]:
                    print("#"+("."*(dimensions[7]))+"d"+("."*(dimensions[0]-(dimensions[7]+3))+"#"))
                else:
                    if i == constant:
                        print("#"+("."*(dimensions[8]))+"P"+("."*(dimensions[0]-(dimensions[8]+3))+"#"))
                    else:
                        if i == dimensions[5]:
                            print("#"+("."*(dimensions[7]))+"*"+("."*(dimensions[0]-(dimensions[7]+3))+"#"))
                        else:
                            if i == dimensions[6]:
                                print("#"+("."*(dimensions[7]))+"M"+("."*(dimensions[0]-(dimensions[7]+3))+"#"))
            print("#"+("."*(dimensions[0]-2))+"#")
        
