class Character:
  def __init__(self):
    self.name = ""
    self.health = 1
    self.health_max = 1
class Player(Character):
  def __init__(self):
    Character.__init__(self)
    self.state = 'normal'
    self.health = 10
    self.health_max = 10
